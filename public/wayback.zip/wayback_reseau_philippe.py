#!/usr/bin/env python3
"""
Wayback Machine CDX API scraper — Réseau Édouard Philippe: entités liées.

Ce script cherche les articles archivés qui mentionnent les entités clés
découvertes dans la cartographie du réseau d'Édouard Philippe.

Il interroge l'API CDX pour chaque combinaison (site × entité).

Usage:
    pip install requests
    python wayback_reseau_philippe.py

Résultat: un CSV par entité + un CSV consolidé.
"""

import requests
import csv
import time
import sys
from datetime import datetime

# Entités du réseau à tracer
NETWORK_ENTITIES = {
    "france-china-foundation": {
        "label": "France China Foundation",
        "patterns": ["france-china-foundation", "francechinafoundation", "france+china+foundation"],
    },
    "french-american-foundation": {
        "label": "French-American Foundation / Young Leaders",
        "patterns": ["french-american-foundation", "young-leaders+french-american", "young+leaders+faf"],
    },
    "ribadeau-dumas": {
        "label": "Benoît Ribadeau-Dumas (dircab Matignon, ENA Marc-Bloch, FCF 2013)",
        "patterns": ["ribadeau-dumas", "ribadeau+dumas"],
    },
    "gilles-boyer": {
        "label": "Gilles Boyer (bras droit, co-auteur, Juppéie)",
        "patterns": ["gilles-boyer", "gilles+boyer"],
    },
    "emmanuel-lenain": {
        "label": "Emmanuel Lenain (créateur FCF, conseiller diplomatique Matignon)",
        "patterns": ["emmanuel-lenain", "emmanuel+lenain"],
    },
    "horizons-parti": {
        "label": "Parti Horizons",
        "patterns": ["horizons+edouard+philippe", "parti-horizons", "horizonsleparti"],
    },
    "philippe-areva": {
        "label": "Édouard Philippe chez Areva (lobbying nucléaire 2007-2010)",
        "patterns": ["edouard-philippe+areva", "philippe+areva+lobbying"],
    },
    "philippe-atos": {
        "label": "Édouard Philippe chez Atos (administrateur depuis 2020)",
        "patterns": ["edouard-philippe+atos", "philippe+atos+administrateur"],
    },
}

# Sites clés (réduit pour les entités moins connues)
SITES_INVESTIGATION = [
    "lemonde.fr",
    "lefigaro.fr",
    "liberation.fr",
    "mediapart.fr",
    "franceinfo.fr",
    "lexpress.fr",
    "lepoint.fr",
    "france24.com",
    "lesechos.fr",
    "challenges.fr",
    "slate.fr",
    "blast-info.fr",
    "publicsenat.fr",
    "bfmtv.com",
    "nouvelobs.com",
    "polemia.com",
    "marianne.net",
]

CDX_API = "https://web.archive.org/cdx/search/cdx"

def query_cdx(site, pattern, max_retries=3):
    params = {
        "url": f"{site}/*{pattern}*",
        "output": "json",
        "fl": "timestamp,original,statuscode",
        "collapse": "urlkey",
        "filter": ["statuscode:200", "mimetype:text/html"],
        "limit": 2000,
    }
    for attempt in range(max_retries):
        try:
            resp = requests.get(CDX_API, params=params, timeout=60)
            resp.raise_for_status()
            data = resp.json()
            return data[1:] if len(data) > 1 else []
        except requests.exceptions.RequestException as e:
            print(f"  ⚠ Erreur {site}/{pattern}: {e}", file=sys.stderr)
            if attempt < max_retries - 1:
                time.sleep(5 * (attempt + 1))
    return []

def format_timestamp(ts):
    try:
        return datetime.strptime(ts, "%Y%m%d%H%M%S").strftime("%Y-%m-%d")
    except ValueError:
        return ts

def make_wayback_url(ts, url):
    return f"https://web.archive.org/web/{ts}/{url}"

def main():
    all_consolidated = []
    
    print("=" * 70)
    print("CARTOGRAPHIE DU RÉSEAU ÉDOUARD PHILIPPE — WAYBACK MACHINE")
    print("=" * 70)
    print()
    
    for entity_key, entity_info in NETWORK_ENTITIES.items():
        entity_results = []
        seen_urls = set()
        
        print(f"🔍 {entity_info['label']}")
        print(f"   Patterns: {entity_info['patterns']}")
        
        for site in SITES_INVESTIGATION:
            for pattern in entity_info["patterns"]:
                results = query_cdx(site, pattern)
                for row in results:
                    url_key = row[1].lower().rstrip("/")
                    if url_key in seen_urls:
                        continue
                    seen_urls.add(url_key)
                    entry = {
                        "entity": entity_info["label"],
                        "entity_key": entity_key,
                        "date": format_timestamp(row[0]),
                        "site": site,
                        "url": row[1],
                        "wayback_url": make_wayback_url(row[0], row[1]),
                    }
                    entity_results.append(entry)
                    all_consolidated.append(entry)
                time.sleep(1.5)  # Rate limiting
        
        entity_results.sort(key=lambda x: x["date"])
        
        # Export CSV par entité
        entity_file = f"wayback_reseau_{entity_key}.csv"
        with open(entity_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["date", "site", "url", "wayback_url"])
            writer.writeheader()
            for r in entity_results:
                writer.writerow({k: r[k] for k in ["date", "site", "url", "wayback_url"]})
        
        if entity_results:
            print(f"   ✅ {len(entity_results)} articles trouvés")
            print(f"   📅 Première mention: {entity_results[0]['date']} — {entity_results[0]['site']}")
            print(f"      {entity_results[0]['url']}")
        else:
            print(f"   ⚠ Aucun article trouvé dans les URLs (recherche par slug uniquement)")
        print(f"   📄 → {entity_file}")
        print()
    
    # Export consolidé
    all_consolidated.sort(key=lambda x: x["date"])
    consolidated_file = "wayback_reseau_philippe_consolide.csv"
    with open(consolidated_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "date", "entity", "entity_key", "site", "url", "wayback_url"
        ])
        writer.writeheader()
        for r in all_consolidated:
            writer.writerow(r)
    
    print("=" * 70)
    print(f"📊 TOTAL: {len(all_consolidated)} articles uniques dans le réseau")
    print(f"📄 Fichier consolidé: {consolidated_file}")
    print()
    
    # Tableau récapitulatif
    print("RÉCAPITULATIF PAR ENTITÉ:")
    print(f"{'Entité':<45} {'Articles':>8} {'1ère mention':>12}")
    print("-" * 70)
    for ek, ei in NETWORK_ENTITIES.items():
        ents = [r for r in all_consolidated if r["entity_key"] == ek]
        first = ents[0]["date"] if ents else "—"
        print(f"{ei['label'][:44]:<45} {len(ents):>8} {first:>12}")

if __name__ == "__main__":
    main()
