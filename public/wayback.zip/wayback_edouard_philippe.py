#!/usr/bin/env python3
"""
Wayback Machine CDX API scraper — Édouard Philippe media coverage tracker.

Ce script interroge l'API CDX de la Wayback Machine pour trouver
toutes les URLs archivées contenant "edouard-philippe" (ou variantes)
dans les chemins des principaux sites d'information français.

L'API CDX ne fait PAS de recherche plein texte — elle cherche dans les URLs.
Comme les sites d'info français incluent le nom dans l'URL de l'article
(slug), c'est un proxy fiable pour la couverture médiatique.

Usage:
    pip install requests
    python wayback_edouard_philippe.py

Résultat: fichier CSV trié par date (plus ancien en premier).
"""

import requests
import csv
import time
import sys
from datetime import datetime

# Sites d'information français à interroger
SITES = [
    "lemonde.fr",
    "lefigaro.fr",
    "liberation.fr",
    "france24.com",
    "franceinfo.fr",
    "leparisien.fr",
    "lexpress.fr",
    "lepoint.fr",
    "mediapart.fr",
    "nouvelobs.com",
    "bfmtv.com",
    "lci.fr",
    "europe1.fr",
    "rtl.fr",
    "ouest-france.fr",
    "20minutes.fr",
    "huffingtonpost.fr",
    "slate.fr",
    "lesechos.fr",
    "latribune.fr",
    "marianne.net",
    "challenges.fr",
    "publicsenat.fr",
    "paris-normandie.fr",
    "francebleu.fr",
    "france3-regions.franceinfo.fr",
    "politico.eu",
]

# Variantes du nom dans les URLs
NAME_PATTERNS = [
    "edouard-philippe",
    "edouard_philippe",
    "edouardphilippe",
]

CDX_API = "https://web.archive.org/cdx/search/cdx"

def query_cdx(site, pattern, max_retries=3):
    """Interroge l'API CDX pour un site et un pattern donné."""
    params = {
        "url": f"{site}/*{pattern}*",
        "output": "json",
        "fl": "timestamp,original,statuscode,mimetype",
        "collapse": "urlkey",  # Déduplique les URLs identiques
        "filter": [
            "statuscode:200",
            "mimetype:text/html",
        ],
        "limit": 5000,
    }
    
    for attempt in range(max_retries):
        try:
            resp = requests.get(CDX_API, params=params, timeout=60)
            resp.raise_for_status()
            data = resp.json()
            if len(data) > 1:  # First row is header
                return data[1:]  # Skip header
            return []
        except requests.exceptions.RequestException as e:
            print(f"  ⚠ Tentative {attempt+1}/{max_retries} échouée pour {site}: {e}", file=sys.stderr)
            if attempt < max_retries - 1:
                time.sleep(5 * (attempt + 1))
    return []

def format_timestamp(ts):
    """Convertit un timestamp CDX (YYYYMMDDhhmmss) en date lisible."""
    try:
        dt = datetime.strptime(ts, "%Y%m%d%H%M%S")
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return ts

def make_wayback_url(timestamp, original_url):
    """Construit l'URL Wayback Machine pour accéder à la capture."""
    return f"https://web.archive.org/web/{timestamp}/{original_url}"

def main():
    all_results = []
    seen_urls = set()
    
    total = len(SITES) * len(NAME_PATTERNS)
    current = 0
    
    print(f"🔍 Interrogation de {len(SITES)} sites × {len(NAME_PATTERNS)} patterns = {total} requêtes")
    print(f"   API CDX: {CDX_API}")
    print()
    
    for site in SITES:
        for pattern in NAME_PATTERNS:
            current += 1
            print(f"[{current}/{total}] {site} / {pattern}...", end=" ", flush=True)
            
            results = query_cdx(site, pattern)
            new_count = 0
            
            for row in results:
                timestamp, original_url = row[0], row[1]
                
                # Déduplique par URL (sans timestamp)
                url_key = original_url.lower().rstrip("/")
                if url_key in seen_urls:
                    continue
                seen_urls.add(url_key)
                
                all_results.append({
                    "date": format_timestamp(timestamp),
                    "timestamp": timestamp,
                    "site": site,
                    "url_originale": original_url,
                    "url_wayback": make_wayback_url(timestamp, original_url),
                })
                new_count += 1
            
            print(f"{new_count} articles trouvés ({len(results)} captures)")
            
            # Rate limiting: respecter les serveurs d'Internet Archive
            time.sleep(2)
    
    # Tri par date (plus ancien en premier)
    all_results.sort(key=lambda x: x["timestamp"])
    
    # Export CSV
    output_file = "edouard_philippe_wayback_articles.csv"
    with open(output_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "date", "site", "url_originale", "url_wayback"
        ])
        writer.writeheader()
        for row in all_results:
            writer.writerow({
                "date": row["date"],
                "site": row["site"],
                "url_originale": row["url_originale"],
                "url_wayback": row["url_wayback"],
            })
    
    print()
    print(f"✅ {len(all_results)} articles uniques trouvés")
    print(f"📄 Résultats exportés dans: {output_file}")
    
    # Résumé par site
    print()
    print("📊 Répartition par site:")
    site_counts = {}
    for r in all_results:
        site_counts[r["site"]] = site_counts.get(r["site"], 0) + 1
    for site, count in sorted(site_counts.items(), key=lambda x: -x[1]):
        print(f"   {site}: {count} articles")
    
    # Première et dernière mention
    if all_results:
        print()
        print(f"📅 Première mention archivée: {all_results[0]['date']}")
        print(f"   → {all_results[0]['url_originale']}")
        print(f"   🔗 {all_results[0]['url_wayback']}")
        print()
        print(f"📅 Dernière mention archivée: {all_results[-1]['date']}")
        print(f"   → {all_results[-1]['url_originale']}")

    # Export résumé chronologique par année
    print()
    print("📈 Volume par année:")
    year_counts = {}
    for r in all_results:
        year = r["date"][:4]
        year_counts[year] = year_counts.get(year, 0) + 1
    for year in sorted(year_counts.keys()):
        bar = "█" * (year_counts[year] // 5) or "▏"
        print(f"   {year}: {year_counts[year]:>4} {bar}")

if __name__ == "__main__":
    main()
